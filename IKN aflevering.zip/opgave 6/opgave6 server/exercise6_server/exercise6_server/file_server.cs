﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace tcp
{
    class file_server
    {
        /// <summary>
        /// The PORT
        /// </summary>
        const int PORT = 9000;
        /// <summary>
        /// The BUFSIZE
        /// </summary>
        const int BUFSIZE = 1000;

		/// <summary>
		/// Initializes a new instance of the <see cref="file_server"/> class.
		/// Opretter en socket.
		/// Venter på en connect fra en klient.
		/// Modtager filnavn
		/// Finder filstørrelsen
		/// Kalder metoden sendFile
		/// Lukker socketen og programmet
		/// </summary>
		private file_server()
		{
			TcpListener server = new TcpListener(IPAddress.Parse("10.0.0.1"), PORT);



			server.Start();

			while (true)
			{
				string path = "../../";
				Console.WriteLine("waiting for connection...");

				var client = server.AcceptTcpClient();
				var Clientip = client.Client.RemoteEndPoint;

				Console.WriteLine(Clientip + " connected!");

				Console.WriteLine("waiting for client to choose file");

				client.Client.SendBufferSize = BUFSIZE;
				client.Client.ReceiveBufferSize = BUFSIZE;

				var data = new Byte[BUFSIZE];
				client.Client.Receive(data);
				path += Encoding.UTF8.GetString(data).Split('\0')[0];
            

				Int32 fileSize = 0;
				if (File.Exists(path))
				{
					fileSize = File.ReadAllBytes(path).Length;
				}
				Console.WriteLine(fileSize);

				if (fileSize == 0)
				{
					Console.WriteLine("file does not exist or is empty!");
					client.Client.Send(BitConverter.GetBytes(fileSize));

				}
				else
				{
					Console.WriteLine("Sending file..");
					//sends file size as the first 4 bytes             
					client.Client.SendFile(path, BitConverter.GetBytes(fileSize), null, TransmitFileOptions.UseDefaultWorkerThread);
					Console.WriteLine("File sent!");
				}
				client.Close();
			}
		}


      


        public static void Main(string[] args)
        {
            Console.WriteLine("Server starts...");
            var server = new file_server();

        }
    }
}
